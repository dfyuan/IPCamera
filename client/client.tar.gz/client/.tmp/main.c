#include "stdinc.h"

extern gboolean connect_app(void);
/*
 * 主函数入口
 * */
gint main(gint argc,gchar* argv[])
{		
	if(!g_thread_supported()) 
		g_thread_init(NULL);
	gdk_threads_init();
	
    gtk_init(&argc, &argv);

    if (FALSE == connect_app()) {
		printf("Connection failure!\n");
		//_exit(EXIT_FAILURE);
	}
    connect_app();
	
	printf("Connection successful!\n");
    _exit(EXIT_SUCCESS);
}




