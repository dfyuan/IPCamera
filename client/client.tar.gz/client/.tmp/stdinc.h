#ifndef __STDINC_H__
	#define __STDINC_H__
	
//��׼ͷ�ļ�
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <time.h>
#include <sys/ioctl.h>
#include <sys/mman.h>
#include <fcntl.h>
#include <signal.h>
#include <linux/types.h> 
#include <linux/videodev2.h>
#include <errno.h>
#include <time.h>

#include <gtk/gtk.h>
#include <glib.h>	

//DEBUG����
#ifndef DEBUG
	#define DBG(fmt, args...)\
		do{} while(0)
#else
	#define DBG(fmt, args...)\
	printf("[%s:%d]"fmt, __func__, __LINE__, ##args)
#endif 

#define ERR_PRINT_RET(ret) \
		{\
			fprintf(stderr, "%s(%d):%s\n", \
		            __func__, __LINE__, strerror(errno));\
			return ret;\
		}

#endif 	//__STDINC_H__
