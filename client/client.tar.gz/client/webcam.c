#include "stdinc.h"
#include "utils.h"
#include "tcputils.h"
#include "frame.h"

#include "webcam.h"

extern GMutex  *g_cam_mutex;
extern GCond   *g_cam_cond;

struct cam_info g_camif;
bool            g_bcamoff = TRUE;    //�Ƿ�ر��豸��ʶ
bool            g_bcamrun = FALSE;   //�Ƿ����ڲɼ���ʶ
bool            g_bcond_wait = FALSE;
bool            g_bcam_thread_quit = TRUE;
static __u32    pic_no    = 0;       //������Ƭ���

/*
 * ���ӷ�����
 * global var: g_camif
 * */
int cam_connect(void)
{
	g_camif.sock = open_cli_sock(g_camif.sip, g_camif.port);
	if (-1 == g_camif.sock) 
		return -1;
	
	return 0;
}

/*
 * ��ʼ������ͷ
 * global var: g_camif
 * */
int cam_init(void)
{
	struct frame_header   fhdr;
	struct ctrl_frame_hdr cfhdr;
	int    sock = g_camif.sock;
	
	bzero(&fhdr, sizeof(struct frame_header));
	
	strncpy(fhdr.fid, FRAME_ID, FRAME_ID_SIZ);
	fhdr.cmd  = MKCMD(TYP_INF, RQT_REQ, DIR_TOS, ACK_NAK);
	write_sock(sock, (__u8*)&fhdr, sizeof(struct frame_header)); 
	
	bzero(&fhdr, sizeof(struct frame_header));
	read_sock(sock, (__u8*)&fhdr, sizeof(struct frame_header));
	if (-1 == cli_ack_pkg_ok(fhdr) || TYP_INF != CMD_TYP(fhdr.cmd)) {
		DBG("cli_ack_pkg_ok is not ok!\n");
		return -1;
	}
		
	g_camif.buf = malloc(fhdr.fsiz);
    DBG("BUF SIZ = %d\n", fhdr.fsiz);
	
	bzero(&cfhdr, sizeof(struct ctrl_frame_hdr));
	read_sock(sock, (__u8*)&cfhdr, sizeof(struct ctrl_frame_hdr));		
	
	strncpy(g_camif.name, cfhdr.name, 32);
	g_camif.pixfmt   = cfhdr.pixfmt;
	g_camif.nr_uctrl = cfhdr.nr_uctrl;
	g_camif.nr_res   = cfhdr.nr_res;			
	g_camif.cres_no  = cfhdr.cres_no;
	
	g_camif.uctrl = 
		malloc(g_camif.nr_uctrl * sizeof(struct v4l2_usrctrl));
	read_sock(sock, (__u8*)g_camif.uctrl, 
			  g_camif.nr_uctrl * sizeof(struct v4l2_usrctrl));			
	
	g_camif.res_list = 
		malloc(g_camif.nr_res * sizeof(struct rect));		
	read_sock(sock, (__u8*)g_camif.res_list, 
			  g_camif.nr_res * sizeof(struct rect));
	
	return 0;
}


int cam_start(void)
{
    g_bcamoff = FALSE;
	g_bcamrun = TRUE;
	
	g_mutex_lock(g_cam_mutex);	
	g_cond_signal(g_cam_cond);
	g_mutex_unlock(g_cam_mutex);	
    
    return 0;
}

/*
 * ��������ͷ
 * global var: g_camif
 * */
int cam_setting_lock(void)
{
	struct frame_header   fhdr;
	struct ctrl_frame_hdr cfhdr;
	int    sock = g_camif.sock;

	g_bcamrun = FALSE;
	g_mutex_lock(g_cam_mutex);
	
	bzero(&fhdr, sizeof(struct frame_header));	
	strncpy(fhdr.fid, FRAME_ID, FRAME_ID_SIZ);
	fhdr.cmd  = MKCMD(TYP_SET, RQT_REQ, DIR_TOS, ACK_NAK);
	write_sock(sock, (__u8*)&fhdr, sizeof(struct frame_header));
	
	bzero(&cfhdr, sizeof(struct ctrl_frame_hdr));
	cfhdr.cres_no = g_camif.res_change;
	write_sock(sock, (__u8*)&cfhdr, sizeof(struct ctrl_frame_hdr));
	
	write_sock(sock, (__u8*)g_camif.uctrl, 
			   g_camif.nr_uctrl * sizeof(struct v4l2_usrctrl));	

    DBG("setting Cam read fhdr\n");
	bzero(&fhdr, sizeof(struct frame_header));
	read_sock(sock, (__u8*)&fhdr, sizeof(struct frame_header));
	if (-1 == cli_ack_pkg_ok(fhdr) || TYP_SET != CMD_TYP(fhdr.cmd)) {
		DBG("cli_ack_pkg_ok is not ok!\n");
		return -1;
	}
	
    DBG("setting Cam read cfhdr\n");
	bzero(&cfhdr, sizeof(struct ctrl_frame_hdr));
	read_sock(sock, (__u8*)&cfhdr, sizeof(struct ctrl_frame_hdr));	

    if (g_camif.cres_no != cfhdr.cres_no) {
        g_camif.cres_no = cfhdr.cres_no;
        g_camif.res_change = TRUE;    
        DBG("res_change, new cres_no = %d, new fsiz = %d\n", 
            cfhdr.cres_no, fhdr.fsiz);
        free(g_camif.buf);
        g_camif.buf = malloc(fhdr.fsiz);
        DBG("BUF SIZ = %d\n", fhdr.fsiz);
    } else {
        g_camif.res_change = FALSE;
    }
	
    DBG("setting Cam read uctrl, nr_uctrl = %d\n",
        cfhdr.nr_uctrl, g_camif.uctrl);
	read_sock(sock, (__u8*)g_camif.uctrl, 
			  g_camif.nr_uctrl * sizeof(struct v4l2_usrctrl));
			  
	return 0;
}

int cam_setting_unlock(void)
{
    g_bcamrun = TRUE;
	g_cond_signal(g_cam_cond);
	g_mutex_unlock(g_cam_mutex);
	
	return 0;
}

int cam_quit(void)
{
	struct frame_header   fhdr;
	struct ctrl_frame_hdr cfhdr;
	int    sock = g_camif.sock;

 	strncpy(fhdr.fid, FRAME_ID, FRAME_ID_SIZ);
	fhdr.cmd = MKCMD(TYP_QUI, RQT_REQ, DIR_TOS, ACK_NAK);
	write_sock(sock, (__u8*)&fhdr, sizeof(struct frame_header));	   

    gdk_threads_leave();
    g_bcamrun = FALSE;
    while (FALSE == g_bcond_wait)
        usleep(1000);
    gdk_threads_enter();

    g_bcamoff = TRUE;
    g_bcamrun = FALSE;

    g_mutex_lock(g_cam_mutex);
    g_cond_signal(g_cam_cond);
    g_mutex_unlock(g_cam_mutex);

    free(g_camif.uctrl);
    free(g_camif.res_list);
    
    while (FALSE == g_bcam_thread_quit)
        usleep(1000);

    return 0;
}

/*
 * ��������ͷ
 * global var: g_camif
 * */
int cam_get_img(void)
{
	struct frame_header   fhdr;
	struct ctrl_frame_hdr cfhdr;
	int    sock = g_camif.sock;

    //DBG("go into\n");

	strncpy(fhdr.fid, FRAME_ID, FRAME_ID_SIZ);
	fhdr.cmd  = MKCMD(TYP_DAT, RQT_REQ, DIR_TOS, ACK_NAK);
	write_sock(sock, (__u8*)&fhdr, sizeof(struct frame_header));			
	
    //DBG("go 0\n");
	bzero(&fhdr, sizeof(struct frame_header));
	read_sock(sock, (__u8*)&fhdr, sizeof(struct frame_header));
    //DBG("go 1\n");
	if (-1 == cli_ack_pkg_ok(fhdr) || TYP_DAT != CMD_TYP(fhdr.cmd)) {
		g_bcamoff = TRUE;
        DBG("get img frame error!\n");
		return -1;
	}
	
	g_camif.len = fhdr.fsiz;
	g_camif.fnr = fhdr.fnr;
	
	read_sock(sock, (__u8*)g_camif.buf, g_camif.len);
	
    //DBG("go out\n");
	return 0;
}

/*
 * ����ͷ�����߳�
 * global var: g_camif
 * */
void* cam_thread(void* args)
{	
    g_bcam_thread_quit = FALSE;
	g_mutex_lock(g_cam_mutex);
	while (g_bcamoff) 
		g_cond_wait(g_cam_cond, g_cam_mutex);
	g_mutex_unlock(g_cam_mutex);

	while (!g_bcamoff) {
		if (g_bcamrun) {	
			g_mutex_lock(g_cam_mutex);
			if (g_bcamrun) {
				if (-1 == cam_get_img()) {
					DBG("cam_get_img error!\n");
				} else {
					gwin_draw_area();
				}
			}
			g_mutex_unlock(g_cam_mutex);	
		} else {
			g_mutex_lock(g_cam_mutex);
			while (!g_bcamrun && !g_bcamoff) {
                g_bcond_wait = TRUE;
				g_cond_wait(g_cam_cond, g_cam_mutex);
            }
			g_mutex_unlock(g_cam_mutex);
            g_bcond_wait = FALSE;
		}
	}	
    DBG("Cam Thread is Over!\n");	
    g_bcam_thread_quit = TRUE;
	return 0;
}

/*
 * ����
 * global var: pic_no, g_camif
 * */ 
int cam_take_picture(void)
{	
	__u8 picname[256];
	
	if (NULL == g_camif.buf || FALSE == g_bcamrun) {
		DBG("camera is not running\n");
		return -1;
	}
	
	do {
		bzero(picname, 256);
		sprintf(picname, PIC_PREFIX "%03d" PIC_POSTFIX, pic_no++);
	} while (!access(picname, F_OK));
	
	DBG("jpeg size = %d\n", g_camif.len);
	if (-1==save_file(picname, g_camif.buf, g_camif.len)) 
		ERR_PRINT_RET(-1);	
	
	return 0;
}

#if 0
/*
 * webcam�ͻ��˳���
 * global var: g_camif
 * */
void* cam_client(void* args)
{
	int i, ret, sock;
	__u8  fid[FRAME_ID_SIZ];    //֡ID
	__u32 cmd;    //֡ID
	struct frame_header   fhdr;
	struct ctrl_frame_hdr cfhdr;	
	bool   bupdate = FALSE;     //ͼ�����
	
	g_camif.fnr = 0;
	g_camif.cbk = NULL;
	g_camif.buf = NULL;
	
	g_mutex_lock(g_cam_mutex);
	while (g_bcamoff) 
		g_cond_wait(g_cam_cond, g_cam_mutex);
	g_mutex_unlock(g_cam_mutex);
	
	sock = g_camif.sock;
	cmd  = g_camif.cmd;
	while (!g_bcamoff) {
		bzero(&fhdr, sizeof(struct frame_header));
		
		switch (CMD_TYP(cmd)) {
		case TYP_INF:
			strncpy(fhdr.fid, FRAME_ID, FRAME_ID_SIZ);
			fhdr.cmd  = MKCMD(TYP_INF, RQT_REQ, DIR_TOS, ACK_NAK);
			write_sock(sock, (__u8*)&fhdr, sizeof(struct frame_header)); 
			
			bzero(&fhdr, sizeof(struct frame_header));
			read_sock(sock, (__u8*)&fhdr, sizeof(struct frame_header));
			if (-1 == cli_ack_pkg_ok(fhdr) || TYP_INF != CMD_TYP(fhdr.cmd)) {
				g_bcamoff = TRUE;
				break;
			}
				
			g_camif.buf = malloc(fhdr.fsiz);
			
			bzero(&cfhdr, sizeof(struct ctrl_frame_hdr));
			read_sock(sock, (__u8*)&cfhdr, sizeof(struct ctrl_frame_hdr));		
			
			strncpy(g_camif.name, cfhdr.name, 32);
			g_camif.pixfmt   = cfhdr.pixfmt;
			g_camif.nr_uctrl = cfhdr.nr_uctrl;
			g_camif.nr_res   = cfhdr.nr_res;			
			g_camif.cres_no  = cfhdr.cres_no;
			
			g_camif.uctrl = 
				malloc(g_camif.nr_uctrl * sizeof(struct v4l2_usrctrl));
			read_sock(sock, (__u8*)g_camif.uctrl, 
			          g_camif.nr_uctrl * sizeof(struct v4l2_usrctrl));			
			
			g_camif.res_list = 
				malloc(g_camif.nr_res * sizeof(struct rect));		
			read_sock(sock, (__u8*)g_camif.res_list, 
			          g_camif.nr_res * sizeof(struct rect));						

			g_camif.cmd = fhdr.cmd;   //gtk�л���ѵ��ֵ
			
			g_mutex_lock(g_cam_mutex);
			while (!g_bcamrun) 
				g_cond_wait(g_cam_cond, g_cam_mutex);
			g_mutex_unlock(g_cam_mutex);			
			
			cmd = g_camif.cmd;
			
			break;
		case TYP_SET:
			strncpy(fhdr.fid, FRAME_ID, FRAME_ID_SIZ);
			fhdr.cmd  = MKCMD(TYP_SET, RQT_REQ, DIR_TOS, ACK_NAK);
			write_sock(sock, (__u8*)&fhdr, sizeof(struct frame_header));
			
			bzero(&cfhdr, sizeof(struct ctrl_frame_hdr));
			cfhdr.cres_no = g_camif.cres_no;
			write_sock(sock, (__u8*)&cfhdr, sizeof(struct ctrl_frame_hdr));
			
			write_sock(sock, (__u8*)g_camif.uctrl, 
			           g_camif.nr_uctrl * sizeof(struct v4l2_usrctrl));	

			bzero(&fhdr, sizeof(struct frame_header));
			read_sock(sock, (__u8*)&fhdr, sizeof(struct frame_header));
			if (-1 == cli_ack_pkg_ok(fhdr) || TYP_SET != CMD_TYP(fhdr.cmd)) {
				//g_bcamoff = TRUE;
				break;
			}
			
			bzero(&cfhdr, sizeof(struct ctrl_frame_hdr));
			read_sock(sock, (__u8*)&cfhdr, sizeof(struct ctrl_frame_hdr));	
			
			g_camif.cres_no = cfhdr.cres_no;
			
			read_sock(sock, (__u8*)cam_info.uctrl, 
			          cam_info.nr_uctrl * sizeof(struct v4l2_usrctrl));
					  
			g_camif.cmd = fhdr.cmd; //gtk��ʱ�����������л���ѵ��ֵ�����½���
			
			cmd = MKCMD(TYP_DAT, RQT_REQ, DIR_TOS, ACK_NAK);
		
			break;		
		case TYP_DAT:
			strncpy(fhdr.fid, FRAME_ID, FRAME_ID_SIZ);
			fhdr.cmd  = MKCMD(TYP_DAT, RQT_REQ, DIR_TOS, ACK_NAK);
			write_sock(sock, (__u8*)&fhdr, sizeof(struct frame_header));			
			
			bzero(&fhdr, sizeof(struct frame_header));
			read_sock(sock, (__u8*)&fhdr, sizeof(struct frame_header));
			if (-1 == cli_ack_pkg_ok(fhdr) || TYP_DAT != CMD_TYP(fhdr.cmd)) {
				g_bcamoff = TRUE;
				break;
			}
			
			g_camif.len = fhdr.fsiz;
			g_camif.fnr = fhdr.fnr;
			
			read_sock(sock, (__u8*)g_camif.buf, g_camif.len);
			
			cmd = g_camif.cmd;
			bupdate = TRUE;
			break;
		default:
			DBG("valid value for g_camif.cmd, do nothing!\n");
			break;
		}
		
		if (NULL != g_camif.cbk && NULL != g_camif.buf &&
			TRUE == bupdate ) {
			g_camif.cbk(g_camif.buf, g_camif.len, g_camif.args);
			bupdate = FALSE;
		}
	} //while
	
	free(g_camif.uctrl);
	free(g_camif.res_list);
	free(g_camif.buf);
	
	close_sock(sock);
	pthread_exit(NULL);		
}

#endif


