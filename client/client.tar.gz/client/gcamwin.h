#ifndef	__GCAMWIN_H__
	#define __GCAMWIN_H__

#include "utils.h"
	
#define WIN_TITLE 	"IP Camera (www.enjoylinux.cn)"
#define WIN_ICON	"./icons/icon.png"

#define TPIC_BT_IMG	"./icons/takepic.png"
#define SETT_BT_IMG	"./icons/settings.png"
#define QUIT_BT_IMG	"./icons/quit.png"

#define CHSP		"    "

//用于记录一项状态的结构
struct widget_item {
    void       *data;
    GtkWidget  *label;
    GtkWidget  *buddy; 		//其他相关控件
};

//总的设备状态
typedef struct {
	struct widget_item  name;		//device capability
	
	struct widget_item  *uctrl;
	__u32               nr_uctrl;	//用户控制项的个数
	
	struct widget_item  csiz;		//捕获一帧图像实际大小
	
	struct widget_item  cres;		//capture width\height
	
	struct widget_item  sip;		//服务器ip
	struct widget_item  port;		//端口号

	GtkWidget           **res_wlist; //capture resolution widget list
	__u32               nr_res;
	
	bool                bfscr;      //是否全屏
	struct rect         fsres;      //全屏分辨率
	
	GdkPixbuf*          pixbuf;		//pixels buffer
	GtkWidget*          darea;		//drawing area
} video_status_t;

extern gboolean create_main_app(void);
	
#endif	//__GCAMWIN_H__



