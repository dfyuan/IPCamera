#ifndef	__GCONWIN_H__
	#define __GCONWIN_H__
	
#define DEF_CONN_IP 	"192.168.1.230"
#define DEF_PORT 	    "8610"
#define LOGO_IMG  	    "./icons/logo.jpg"
	
struct status_msg {
	guint cid;
//	guint mid;
	gchar *text;
} ;
	
#endif	//__GCONWIN_H__
