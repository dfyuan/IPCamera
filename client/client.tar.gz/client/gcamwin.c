#include "stdinc.h"
#include "utils.h"
#include "webcam.h"

#include "gcamwin.h"

extern struct cam_info g_camif;

video_status_t g_vst;	//global video status var

void main_quit(GtkWidget *Object, gpointer data)
{
    DBG("get quit signal!\n");
    cam_quit();
    gtk_main_quit();
}

////////////////////////////////
//  DRAW AREA
//
gboolean 
mouse_2button_press_darea(GtkWidget *widget,
                          GdkEventButton *event, 
						  gpointer data)
{
	GtkWidget* darea  = widget;
	GtkWidget* window = (GtkWidget*)data;
	
	if (event->type == GDK_2BUTTON_PRESS && 
	    event->button == 0x1) {
		DBG("Double Click Left Mouse\n");
		if (TRUE == g_vst.bfscr) {
			g_vst.bfscr = FALSE;

            gtk_widget_hide_all(window);

            gtk_window_set_position(GTK_WINDOW(window), 
                                    GTK_WIN_POS_CENTER);  
			gtk_drawing_area_size(GTK_DRAWING_AREA(darea),
								  ((struct rect*)(g_vst.cres.data))->w, 
								  ((struct rect*)(g_vst.cres.data))->h);				

			gtk_window_unfullscreen(GTK_WINDOW(window));
			gtk_window_unmaximize(GTK_WINDOW(window));
            gtk_widget_show_all(window);
		} else {
			g_vst.bfscr = TRUE;
            gtk_widget_hide_all(window);

            gtk_window_set_position(GTK_WINDOW(window), 
                                    GTK_WIN_POS_CENTER);  
			gtk_drawing_area_size(GTK_DRAWING_AREA(darea),
								  g_vst.fsres.w, 
								  g_vst.fsres.h);	

			gtk_window_maximize(GTK_WINDOW(window));
			gtk_window_fullscreen(GTK_WINDOW(window));
            gtk_widget_show_all(window);
		}
	}
	
	return FALSE;
}

/*
 * 获得drawing area，并将它放进box里
 * global var: g_vst
 * */
static gboolean
drawarea_setup(GtkWidget* window, GtkWidget* box)
{
	GtkWidget* frame;

	frame = gtk_frame_new("视频区");
	gtk_box_pack_start_defaults(GTK_BOX(box), frame);
	gtk_container_add(GTK_CONTAINER(frame), g_vst.darea);
    
    gtk_widget_add_events(GTK_WIDGET(g_vst.darea), 
                          GDK_BUTTON_PRESS_MASK);
	g_signal_connect(GTK_OBJECT(g_vst.darea), 
	                 "button-press-event", 
					 G_CALLBACK(mouse_2button_press_darea), 
					 window);
    
    gtk_drawing_area_size(GTK_DRAWING_AREA(g_vst.darea),
	                      ((struct rect*)(g_vst.cres.data))->w, 
						  ((struct rect*)(g_vst.cres.data))->h);	
						  

	
	return TRUE;
}

////////////////////////////////
//  LABEL AREA
//
/*
 * 获得label area，并将它放进box里
 * global var: g_vst
 * */
static gboolean
labelarea_setup(GtkWidget* window, GtkWidget* box)
{
	gint i;
	GtkWidget* frame;
	GtkWidget* vbox;
	GtkWidget* hseparator;
	
	frame = gtk_frame_new("状态区");
	gtk_box_pack_start_defaults(GTK_BOX(box), frame);
	vbox = gtk_vbox_new(FALSE, 5);
	gtk_container_add(GTK_CONTAINER(frame), vbox);
	//-----------------DEV NAME--------------------------------------
    gtk_box_pack_start_defaults(GTK_BOX(vbox), g_vst.name.label);
	hseparator = gtk_hseparator_new(); 
    gtk_box_pack_start_defaults(GTK_BOX(vbox), hseparator);	
	//-----------------IP & PORT-------------------------------------
    gtk_box_pack_start_defaults(GTK_BOX(vbox), g_vst.sip.label);
    //gtk_box_pack_start_defaults(GTK_BOX(vbox), g_vst.port.label);
	hseparator = gtk_hseparator_new(); 
    gtk_box_pack_start_defaults(GTK_BOX(vbox), hseparator);	
	//-----------------Caoture Frame Size----------------------------
	GtkWidget* __align = gtk_alignment_new(1, 0, 0, 0);		//下对齐
	gtk_box_pack_start_defaults(GTK_BOX(vbox), __align);
	
	GtkWidget* __vbox = gtk_vbox_new(FALSE, 0);	
	//gtk_box_pack_start_defaults(GTK_BOX(vbox), __vbox);	
	gtk_container_add(GTK_CONTAINER(__align), __vbox);	
	
	gtk_box_pack_start_defaults(GTK_BOX(__vbox), gtk_label_new("捕获大小(byte):"));	
	
	frame = gtk_frame_new("");
	gtk_box_pack_start_defaults(GTK_BOX(__vbox), frame);
	gtk_container_add(GTK_CONTAINER(frame), g_vst.csiz.label);
	
	hseparator = gtk_hseparator_new(); 
    gtk_box_pack_start_defaults(GTK_BOX(vbox), hseparator);		
	//-----------------User Control----------------------------------
	for (i = 0; i < g_vst.nr_uctrl; i++) {
	    if (NULL == g_vst.uctrl[i].label)
            continue;
        gtk_box_pack_start_defaults(GTK_BOX(vbox), g_vst.uctrl[i].label);
    }
	hseparator=gtk_hseparator_new(); 
    gtk_box_pack_start_defaults(GTK_BOX(vbox), hseparator);	
	//-----------------Resolution------------------------------------	
    gtk_box_pack_start_defaults(GTK_BOX(vbox), g_vst.cres.label);
	
	return TRUE;
}

////////////////////////////////
//  SET AREA
//
/*
 * 获得setting area，并将它放进box里
 * global var: g_vst
 * */
static gboolean
setarea_setup(GtkWidget* window, GtkWidget* box)
{
	gint i=0;
	
	GtkWidget* frame;
	GtkWidget* vbox;
	GtkWidget* hbox;
	GtkWidget* label;
	GtkWidget* vseparator;
	GtkWidget* align;
	gchar      lstr[32];
	
	frame=gtk_frame_new("设置区");
	gtk_box_pack_start_defaults(GTK_BOX(box), frame);
	vbox=gtk_vbox_new(FALSE, 5);
	gtk_container_add(GTK_CONTAINER(frame), vbox);
	// ----------------------------------------------------------------
	//__u8 div = ((struct rect*)(g_vst.cres.data))->w/160;
	__u8 div = 3; 
    int j = -1;
    for (i = 0; i < g_vst.nr_uctrl; i++) {

        if (NULL == g_vst.uctrl[i].buddy) 
            continue;
        j++;
		if (0 == j%div) {
			align = gtk_alignment_new(0, 0, 0, 0);		//左对齐
			gtk_box_pack_start_defaults(GTK_BOX(vbox), align);
			
			hbox  = gtk_hbox_new(FALSE, 5);
			gtk_container_add(GTK_CONTAINER(align), hbox);		
		} else {
			vseparator=gtk_vseparator_new(); 
			gtk_box_pack_start_defaults(GTK_BOX(hbox), vseparator);
		}	
		if (V4L2_CTRL_TYPE_INTEGER == 
		    ((struct v4l2_usrctrl*)g_vst.uctrl[i].data)->type) {
			sprintf(lstr, "%s(%d, %d)", 
			        ((struct v4l2_usrctrl*)g_vst.uctrl[i].data)->name, 
					((struct v4l2_usrctrl*)g_vst.uctrl[i].data)->min,
					((struct v4l2_usrctrl*)g_vst.uctrl[i].data)->max);
			
		} else if (V4L2_CTRL_TYPE_BOOLEAN ==         
            ((struct v4l2_usrctrl*)g_vst.uctrl[i].data)->type) {
			sprintf(lstr, "%s", 
			        ((struct v4l2_usrctrl*)g_vst.uctrl[i].data)->name);		
		}
		label = gtk_label_new(lstr);
		gtk_box_pack_start_defaults(GTK_BOX(hbox), label);	
		gtk_box_pack_start_defaults(GTK_BOX(hbox), g_vst.uctrl[i].buddy);
	}
	
	// ----------------------------------------------------------------
	align = gtk_alignment_new(0, 0, 0, 0);		//左对齐
	gtk_box_pack_start_defaults(GTK_BOX(vbox), align);
	
	hbox  = gtk_hbox_new(FALSE, 5);
	gtk_container_add(GTK_CONTAINER(align), hbox);
	
	label = gtk_label_new("分辨率");
    gtk_box_pack_start_defaults(GTK_BOX(hbox), label);	

	for (i=0; i < g_vst.nr_res; i++) 
		gtk_box_pack_start_defaults(GTK_BOX(hbox), g_vst.res_wlist[i]);
	
	return TRUE;
}

////////////////////////////////
//  BUTTON AREA
//
/*
 * 点击【拍照】，槽函数
 * */
static gboolean
take_picture(GtkWidget* widget, gpointer data)
{
	cam_take_picture();
    system("play ./icons/camera.wav");
}

void* setting_thread(void* args)
{
	gint i;
	GtkButton *button = (GtkButton*)args;
	gchar     lstr[32];
    
    if (-1 == cam_setting_lock()) {
		DBG("cam_setting error!\n");
		cam_quit();
		gtk_main_quit();
	} else {
		gdk_threads_enter();
	
		if (TRUE == g_camif.res_change) {
            g_camif.res_change = FALSE;
			g_vst.cres.data = (void*)&g_camif.res_list[g_camif.cres_no];
		    DBG("RES is really change, cres_no = %d\n", 
                g_camif.cres_no);	
			gtk_drawing_area_size(GTK_DRAWING_AREA(g_vst.darea),
								  ((struct rect*)(g_vst.cres.data))->w, 
								  ((struct rect*)(g_vst.cres.data))->h);	

			sprintf(lstr, "分辨率  :  %dx%d", 
					((struct rect*)(g_vst.cres.data))->w, 
					((struct rect*)(g_vst.cres.data))->h);	
			gtk_label_set_text(GTK_LABEL(g_vst.cres.label), lstr);				
		}
	
		for (i = 0; i < g_vst.nr_uctrl; i++) {
			switch (((struct v4l2_usrctrl*)g_vst.uctrl[i].data)->type) {
			case V4L2_CTRL_TYPE_INTEGER:
				sprintf(lstr, "%s:  %5d",	
						((struct v4l2_usrctrl*)g_vst.uctrl[i].data)->name, 
						((struct v4l2_usrctrl*)g_vst.uctrl[i].data)->val ); 	
				gtk_label_set_text(GTK_LABEL(g_vst.uctrl[i].label), lstr);
				gtk_spin_button_set_value(
					GTK_SPIN_BUTTON(g_vst.uctrl[i].buddy), 
					((struct v4l2_usrctrl*)g_vst.uctrl[i].data)->val);
				break;

			case V4L2_CTRL_TYPE_BOOLEAN:					
					sprintf(lstr, "%s:  %s",	
							((struct v4l2_usrctrl*)g_vst.uctrl[i].data)->name, 
							((struct v4l2_usrctrl*)g_vst.uctrl[i].data)->val ? "on" : "off" ); 						
					gtk_label_set_text(GTK_LABEL(g_vst.uctrl[i].label), lstr);	
					gtk_toggle_button_set_active(
						GTK_TOGGLE_BUTTON(g_vst.uctrl[i].buddy),
						((struct v4l2_usrctrl*)g_vst.uctrl[i].data)->val);				
				break;
			default:
				break;
			}		
		}			
		gdk_threads_leave();
	}
    cam_setting_unlock(); 
	gtk_widget_set_sensitive(GTK_WIDGET(button), TRUE);
}

/*
 * 点击【设置】，槽函数
 * global var: g_vst、g_camif
 * */
static gboolean
set_video_status(GtkButton* button, gpointer data)
{
	gint  i = 0;
	gchar lstr[36];
	
	//--------------Capture Size Select----------------------------------
	for (i = 0; i < g_vst.nr_res; i++) {
		if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(g_vst.res_wlist[i])))
			break;
	}	
	if (i == g_vst.nr_res)
		i = 0;
    
    g_camif.res_change = i;
	
	for (i = 0; i < g_vst.nr_uctrl; i++) {
        if (NULL == g_vst.uctrl[i].buddy)
            continue;

        switch (((struct v4l2_usrctrl*)g_vst.uctrl[i].data)->type) {
        case V4L2_CTRL_TYPE_INTEGER:
			g_camif.uctrl[i].val = gtk_spin_button_get_value_as_int(
								    GTK_SPIN_BUTTON(g_vst.uctrl[i].buddy));				
            break;
        case V4L2_CTRL_TYPE_BOOLEAN:

		    g_camif.uctrl[i].val = gtk_toggle_button_get_active(
							        GTK_TOGGLE_BUTTON(g_vst.uctrl[i].buddy));
            break;
        default:
            break;
	    }
    }
	
	gtk_widget_set_sensitive(GTK_WIDGET(button), FALSE);
	
	g_thread_create(setting_thread, button, FALSE, NULL);
	
	return TRUE;
}

/*
 * 获得button area，并将它放进box里
 * global var: g_vst
 * */
static gboolean
buttonarea_setup(GtkWidget* window, GtkWidget* box)
{
	GtkWidget* frame;
	GtkWidget* vbuttonbox;
	GtkWidget* button;		
	GtkWidget* hbox;		
	GtkWidget* label;	
	GtkWidget* image;	

	frame=gtk_frame_new("");
	gtk_box_pack_start_defaults(GTK_BOX(box), frame);
	GtkWidget* __align=gtk_alignment_new(1, 0, 0, 0);		//right对齐
	gtk_container_add(GTK_CONTAINER(frame), __align);	
	
	vbuttonbox=gtk_vbutton_box_new();
	gtk_container_add(GTK_CONTAINER(__align), vbuttonbox);
	// ----------------------------------------------------------------
	// ----------------------------------------
	image=gtk_image_new_from_file(TPIC_BT_IMG);
	label=gtk_label_new("拍照" CHSP);
	hbox=gtk_hbox_new(FALSE, 5);
	gtk_box_pack_start_defaults(GTK_BOX(hbox), image);
	gtk_box_pack_start_defaults(GTK_BOX(hbox), label);
	button=gtk_button_new();	
	gtk_container_add(GTK_CONTAINER(button), hbox);
	
	gtk_box_pack_start_defaults(GTK_BOX(vbuttonbox), button);
    gtk_signal_connect(GTK_OBJECT(button), "clicked",
                       GTK_SIGNAL_FUNC(take_picture),
                       window);	

	// ----------------------------------------
	image=gtk_image_new_from_file(SETT_BT_IMG);
	label=gtk_label_new("设置" CHSP);
	hbox=gtk_hbox_new(FALSE, 5);
	gtk_box_pack_start_defaults(GTK_BOX(hbox), image);
	gtk_box_pack_start_defaults(GTK_BOX(hbox), label);
	button=gtk_button_new();	
	gtk_container_add(GTK_CONTAINER(button), hbox);	
	
	gtk_box_pack_start_defaults(GTK_BOX(vbuttonbox), button);	
    gtk_signal_connect(GTK_OBJECT(button), "clicked",
                       GTK_SIGNAL_FUNC(set_video_status),
                       window);	
	
	// ----------------------------------------
	image=gtk_image_new_from_file(QUIT_BT_IMG);
	label=gtk_label_new("关闭" CHSP);
	hbox=gtk_hbox_new(FALSE, 5);
	gtk_box_pack_start_defaults(GTK_BOX(hbox), image);
	gtk_box_pack_start_defaults(GTK_BOX(hbox), label);
	button=gtk_button_new();	
	gtk_container_add(GTK_CONTAINER(button), hbox);
	
	gtk_box_pack_start_defaults(GTK_BOX(vbuttonbox), button);
    gtk_signal_connect(GTK_OBJECT(button), "clicked",
                       GTK_SIGNAL_FUNC(main_quit),
                       window);	
	
	return TRUE;
}

////////////////////////////////
//  MAIN INTERFACE INIT
//
/*
 * 界面初始化
 * */
static gboolean
init_main_if(GtkWidget* window)
{
    GtkWidget* vbox;
    GtkWidget* hbox;	
    GtkWidget* hseparator;	

    vbox=gtk_vbox_new(FALSE, 5);
    gtk_container_add(GTK_CONTAINER(window), vbox);          
 	//----------------------------------------------------------   
    hbox=gtk_hbox_new(FALSE, 5);
    gtk_box_pack_start_defaults(GTK_BOX(vbox), hbox);
	drawarea_setup(window, hbox);
		
	labelarea_setup(window, hbox);	
	//----------------------------------------------------------
	hseparator=gtk_hseparator_new(); 
    gtk_box_pack_start_defaults(GTK_BOX(vbox), hseparator);
	//----------------------------------------------------------
    hbox=gtk_hbox_new(FALSE, 5);
    gtk_box_pack_start_defaults(GTK_BOX(vbox), hbox);
	setarea_setup(window, hbox);
	
	buttonarea_setup(window, hbox);
	//----------------------------------------------------------    
    return TRUE;
}

/*
 * 填充全局状态结构，同时也初始化采集
 * global var: g_vst, g_camif
 * call connect_app() first, in main()
 * */
static void video_status_setup(GtkWidget* window)
{
    gint i;
	gchar lstr[36];
	
	//---------------name, csiz, vidw, vidh--------------------------
    g_vst.cres.data = (void*)&g_camif.res_list[g_camif.cres_no];  

	g_vst.name.data = g_camif.name;
	g_vst.sip.data  = g_camif.sip;
	g_vst.port.data = (void*)(g_camif.port);
	
	g_vst.csiz.data = 0;
	
	sprintf(lstr, "设备名称:  %s", (gchar*)g_vst.name.data);
	g_vst.name.label = gtk_label_new(lstr);

	sprintf(lstr, "服务器:  %s:%d", (gchar*)g_vst.sip.data,
                                      (gint)g_vst.port.data);
	g_vst.sip.label = gtk_label_new(lstr);
	
	//sprintf(lstr, "端口号  :  %5d", (gint)g_vst.port.data);
	//g_vst.port.label = gtk_label_new(lstr);	
	
	sprintf(lstr, "%d", (gint)g_vst.csiz.data); 	//捕获大小:\t
	g_vst.csiz.label = gtk_label_new(lstr);	

	sprintf(lstr, "分辨率  :  %dx%d", 
	        ((struct rect*)(g_vst.cres.data))->w, 
			((struct rect*)(g_vst.cres.data))->h);
	g_vst.cres.label = gtk_label_new(lstr);	

	g_vst.bfscr = FALSE;
	GdkScreen *screen = gtk_window_get_screen(GTK_WINDOW(window));  
	g_vst.fsres.w = gdk_screen_get_width(screen);
	g_vst.fsres.h = gdk_screen_get_height(screen);	
	
	//----------------user control------------------------------------
    g_vst.nr_uctrl = g_camif.nr_uctrl;
	g_vst.uctrl = (struct widget_item*)calloc(g_vst.nr_uctrl, 
	                                          sizeof(struct widget_item));
											  
    for (i = 0; i < g_vst.nr_uctrl; i++) {
        g_vst.uctrl[i].data = &g_camif.uctrl[i];
		
        switch (((struct v4l2_usrctrl*)g_vst.uctrl[i].data)->type) {
        case V4L2_CTRL_TYPE_INTEGER:
			sprintf(lstr, "%s:  %5d",	
			        ((struct v4l2_usrctrl*)g_vst.uctrl[i].data)->name, 
				    ((struct v4l2_usrctrl*)g_vst.uctrl[i].data)->val );
					
			g_vst.uctrl[i].label = gtk_label_new(lstr);		
		
			g_vst.uctrl[i].buddy = 
				gtk_spin_button_new_with_range(
					((struct v4l2_usrctrl*)g_vst.uctrl[i].data)->min, 
				    ((struct v4l2_usrctrl*)g_vst.uctrl[i].data)->max, 1);	
					
			gtk_spin_button_set_value(GTK_SPIN_BUTTON(g_vst.uctrl[i].buddy), 
			                          ((struct v4l2_usrctrl*)g_vst.uctrl[i].data)->val);
            break;

        case V4L2_CTRL_TYPE_BOOLEAN:
			sprintf(lstr, "%s:  %s", 
			        ((struct v4l2_usrctrl*)g_vst.uctrl[i].data)->name, 
					((struct v4l2_usrctrl*)g_vst.uctrl[i].data)->val ? "on" : "off" ); 	       
			g_vst.uctrl[i].label = gtk_label_new(lstr);				
		
			g_vst.uctrl[i].buddy = gtk_check_button_new();
			gtk_toggle_button_set_active(
				GTK_TOGGLE_BUTTON(g_vst.uctrl[i].buddy),
				((struct v4l2_usrctrl*)g_vst.uctrl[i].data)->val);
            break;
		default:
            DBG("type = %x\n", 
                ((struct v4l2_usrctrl*)g_vst.uctrl[i].data)->type);
            g_vst.uctrl[i].label = NULL;
            g_vst.uctrl[i].buddy = NULL;
			break;
        }		
	}
    
	//-----------resolution-------------------------------------------
	sprintf(lstr, "%dx%d", g_camif.res_list[0].w, g_camif.res_list[0].h);
	
	g_vst.nr_res    = g_camif.nr_res;
	g_vst.res_wlist = (GtkWidget**)malloc(g_vst.nr_res * sizeof(GtkWidget*));
	g_vst.res_wlist[0] = gtk_radio_button_new_with_label(NULL, lstr); 	
	for (i = 0; i < g_vst.nr_res; i++) {
		sprintf(lstr, "%dx%d", g_camif.res_list[i].w, g_camif.res_list[i].h);
		g_vst.res_wlist[i] = gtk_radio_button_new_with_label_from_widget(
			                    GTK_RADIO_BUTTON(g_vst.res_wlist[0]), lstr);
	}

	gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(g_vst.res_wlist[0]), TRUE),	 
	
	//-----------drawing area setup-----------------------------------
	g_vst.darea = gtk_drawing_area_new();
    DBG("g_vst.darea = 0x%x\n", g_vst.darea);
}

/*
 * 更新视频区
 * global var: g_vst, g_camif
 * @ 在完成一帧图形采集时调用
 * @ 同时会更新g_vst.csiz
 * @ 在工作线程中调用了修改界面的语句，要在修改界面的语句前加
 * gdk_threads_enter()进入线程锁定，以防界面线程和工作线程冲突，
 * 导致界面假死，修改完界面后再使用gdk_threads_leave()解除锁定。
 * */
void gwin_draw_area(void)
{
	gchar lstr[36];
	__u8 *buf = (__u8*)g_camif.buf;
	gint fsiz  = (gint)g_camif.len;
	GtkWidget *darea = (GtkWidget*)g_vst.darea;

	gdk_threads_enter();

	GdkPixbufLoader* pixbuf_loader = gdk_pixbuf_loader_new(); 		

 	gdk_pixbuf_loader_write(pixbuf_loader, buf, fsiz, 0); // 
	gdk_pixbuf_loader_close(pixbuf_loader, 0); // 
	g_vst.pixbuf = (GdkPixbuf*)g_object_ref(
        gdk_pixbuf_loader_get_pixbuf(pixbuf_loader)); //
    g_object_unref(pixbuf_loader);
    
/*    DBG("pixbuf.w = %d, pixbuf.h = %d\n", 
        gdk_pixbuf_get_width(GDK_PIXBUF(g_vst.pixbuf)),
        gdk_pixbuf_get_height(GDK_PIXBUF(g_vst.pixbuf)));*/
	
    gtk_widget_realize(darea);
	
	if (TRUE == g_vst.bfscr) {
		GdkPixbuf *pixbuf = gdk_pixbuf_scale_simple(g_vst.pixbuf,
		                                            g_vst.fsres.w,
		                                            g_vst.fsres.h,
						     						GDK_INTERP_NEAREST);
		
		gdk_draw_pixbuf(GTK_WIDGET(darea)->window, NULL, pixbuf, 
						0, 0, 0, 0, 
						g_vst.fsres.w, 
						g_vst.fsres.h, 
						GDK_RGB_DITHER_NORMAL, 0, 0);	
						
		if (pixbuf != NULL) 
			g_object_unref(pixbuf);	
	} else {
		gdk_draw_pixbuf(GTK_WIDGET(darea)->window, NULL, g_vst.pixbuf, 
						0, 0, 0, 0, 
						((struct rect*)(g_vst.cres.data))->w, 
						((struct rect*)(g_vst.cres.data))->h, 
						GDK_RGB_DITHER_NORMAL, 0, 0);	
	}

    
    if (g_vst.pixbuf != NULL) {
        g_object_unref(g_vst.pixbuf);
        g_vst.pixbuf = NULL;
    }

	//更新g_vst.csiz
	g_vst.csiz.data = (void*)fsiz;
	sprintf(lstr, "%d", (gint)g_vst.csiz.data);
	gtk_label_set_text(GTK_LABEL(g_vst.csiz.label), lstr);
		
	gdk_threads_leave();
}

/*
 * 创建主应用程序窗口
 * */
gboolean create_main_app(void)
{
    GtkWidget* window;

    window=gtk_window_new(GTK_WINDOW_TOPLEVEL);  //新建一个顶层窗口		
 	
	video_status_setup(window);
 
    gtk_window_set_title(GTK_WINDOW(window), WIN_TITLE);  //设置窗口标题
    gtk_window_set_position(GTK_WINDOW(window), GTK_WIN_POS_CENTER);  //窗口出现在屏中央
    gtk_window_set_icon(GTK_WINDOW(window), 
                        gdk_pixbuf_new_from_file(WIN_ICON, NULL));
    gtk_window_set_resizable(GTK_WINDOW(window), FALSE);   //不可改变窗口大小
    gtk_container_set_border_width(GTK_CONTAINER(window), 0);  //窗口边框大小设置为0 
    gtk_signal_connect(GTK_OBJECT(window), "destroy",
                       GTK_SIGNAL_FUNC(main_quit),NULL);
	//gtk_widget_set_size_request(window, 800, 600);

    gtk_widget_set_app_paintable(window, TRUE);
    gtk_widget_realize (window);

	init_main_if(window);

    gtk_widget_show_all(window);

    cam_start();

    return TRUE;
}

