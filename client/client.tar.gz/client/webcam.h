#ifndef	__WEBCAM_H__
	#define __WEBCAM_H__
	
#include "utils.h"

#define PIC_PREFIX		"./images/cam"
#define PIC_POSTFIX		".jpg"

struct cam_info {
	int                   sock;       //�׽���
	__u8                  name[32];   //�豸����
	
	__u8                  *sip;       //������ip
	__u32                 port;       //�˿ں�
		
	__u32                 pixfmt;     //���ظ�ʽ
	
	struct v4l2_usrctrl   *uctrl;     //�û�������
	__u32                 nr_uctrl;
	
	struct rect           *res_list;  //֧�ֵķֱ����б�
	__u32                 nr_res;     //�ܹ�֧�ֵķֱ���
	__u32                 cres_no;    //��ǰ�ֱ��ʱ��
    __u32                 res_change;	
	void                  *buf;
	__u32                 len;
	 
	__u32                 fnr;        //֡���
};	

extern int cam_connect(void);
extern void* cam_thread(void* args);
extern int cam_init(void);	
extern int cam_start(void);	
extern int cam_setting_lock(void);	
extern int cam_setting_unlock(void);	
extern int cam_quit(void);	
extern int cam_take_picture(void);
	
#endif	//__WEBCAM_H__
