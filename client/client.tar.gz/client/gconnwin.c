#include "stdinc.h"
#include "gcamwin.h"
#include "webcam.h"

#include "gconnwin.h"

extern struct cam_info g_camif;

struct status_msg g_status_msg[] = {
	#define MID_FIRST_PROMPT 0
	[0].text = "click \'Connect\' to connect to the Server",
	#define MID_CONN_PROMPT  1
	[1].text = "click to Connect",
	#define MID_QUIT_PROMPT  2
	[2].text = "clict to Quit",
	#define MID_CONN_NOW     3
	[3].text = "connecting now, please wait ...",
	#define MID_CONN_FAIL    4
	[4].text = "connection fail",
	#define MID_CONN_OK      5
	[5].text = "connection successful",
};

static GtkWidget *statusbar;
static GtkWidget *ip_entry;
static GtkWidget *port_entry;
static gboolean  conn_stutas = FALSE; 
static gulong    conn_btn_leave_id; 

////////////////////////////////
//  IMAGE
//
static gboolean
imagearea_setup(GtkWidget* window, GtkWidget* box)
{
	GtkWidget *image;	
	
	image = gtk_image_new_from_file(LOGO_IMG);
	gtk_box_pack_start_defaults(GTK_BOX(box), image);
	
	return TRUE;
}

////////////////////////////////
//  ENTRY
//
static void 
entry_ipaddr_filter(GtkWidget* entry, 
                     gchar* new_text, 
					 int new_text_length, 
					 int* position)
{
    if (new_text[0] > '9' || new_text[0] < '0' && 
	    new_text[0] != '.')  
       new_text[0] = '\0';
}

static void 
entry_numeric_filter(GtkWidget* entry, 
                     gchar* new_text, 
					 int new_text_length, 
					 int* position)
{
    if (new_text[0] > '9' || new_text[0] < '0') 
       new_text[0] = '\0';
}

static gboolean
entryarea_setup(GtkWidget* window, GtkWidget* box)
{
	GtkWidget *label;	

	label = gtk_label_new("Connect to: ");
    gtk_box_pack_start_defaults(GTK_BOX(box), label);
	
	ip_entry = gtk_entry_new();
	gtk_entry_set_text(GTK_ENTRY(ip_entry), DEF_CONN_IP);
	gtk_entry_set_max_length(GTK_ENTRY(ip_entry), 15);
	g_signal_connect (G_OBJECT (ip_entry), 
	                  "insert-text", 
					  G_CALLBACK(entry_ipaddr_filter), 
					  NULL);
    gtk_box_pack_start_defaults(GTK_BOX(box), ip_entry);	
	
	label = gtk_label_new("Port: ");
    gtk_box_pack_start_defaults(GTK_BOX(box), label);	

	port_entry = gtk_entry_new();
	gtk_entry_set_text(GTK_ENTRY(port_entry), DEF_PORT);
	gtk_entry_set_max_length(GTK_ENTRY(port_entry), 5);
	g_signal_connect (G_OBJECT (port_entry), 
	                  "insert-text", 
					  G_CALLBACK(entry_numeric_filter), 
					  NULL);
    gtk_box_pack_start_defaults(GTK_BOX(box), port_entry);		

	return TRUE;
}

////////////////////////////////
//  BUTTON
//
void* connect_thread(void* args)
{
	GtkButton *button = (GtkButton*)args;
	
	//conn_btn_leave_id
	g_signal_handler_block(GTK_OBJECT(button), conn_btn_leave_id);
	if (0 == cam_connect()) {
		if (-1 == cam_init()) 
			return;

		conn_stutas = TRUE;
		gtk_main_quit();
	} else {
		gdk_threads_enter();
		gtk_widget_set_sensitive(GTK_WIDGET(ip_entry), TRUE);
		gtk_widget_set_sensitive(GTK_WIDGET(port_entry), TRUE);
		
		gtk_statusbar_pop(GTK_STATUSBAR(statusbar), 
						   g_status_msg[MID_CONN_NOW].cid);	
					   
		gtk_statusbar_push(GTK_STATUSBAR(statusbar), 
						   g_status_msg[MID_CONN_FAIL].cid, 
						   g_status_msg[MID_CONN_FAIL].text);
		
		gtk_widget_set_sensitive(GTK_WIDGET(button), TRUE);		
		gdk_threads_leave();
	}
	g_signal_handler_unblock(GTK_OBJECT(button), conn_btn_leave_id);
}

void 
connect_handler(GtkButton *button, gpointer data) 
{
	g_camif.sip   = strdup(gtk_entry_get_text(GTK_ENTRY(ip_entry)));
	g_camif.port = atoi(gtk_entry_get_text(GTK_ENTRY(port_entry)));
	
	DBG("Connect IP = %s, Port = %d\n", g_camif.sip, g_camif.port);
	
	gtk_widget_set_sensitive(GTK_WIDGET(ip_entry), FALSE);
	gtk_widget_set_sensitive(GTK_WIDGET(port_entry), FALSE);
	
	gtk_statusbar_pop(GTK_STATUSBAR(statusbar), 
	                  g_status_msg[MID_CONN_PROMPT].cid);	
	
	gtk_statusbar_push(GTK_STATUSBAR(statusbar), 
	                   g_status_msg[MID_CONN_NOW].cid, 
	                   g_status_msg[MID_CONN_NOW].text);
	
	gtk_widget_set_sensitive(GTK_WIDGET(button), FALSE);

	g_thread_create(connect_thread, button, FALSE, NULL);	
}

gboolean  
button_enter(GtkButton *button, gpointer data)
{
	guint mid = (guint)data;
	gtk_statusbar_push(GTK_STATUSBAR(statusbar), 
	                   g_status_msg[mid].cid, 
	                   g_status_msg[mid].text);	
	
	return TRUE;
}   

gboolean  
button_leave(GtkButton *button, gpointer data)
{
	guint mid = (guint)data;
	
	gtk_statusbar_pop(GTK_STATUSBAR(statusbar), 
					  g_status_msg[MID_CONN_FAIL].cid);	

	//gtk_statusbar_remove_all(GTK_STATUSBAR(statusbar), 
	//				  g_status_msg[MID_CONN_FAIL].cid);	
					   
	gtk_statusbar_pop(GTK_STATUSBAR(statusbar), 
	                  g_status_msg[mid].cid);	

	return TRUE;
}  

gboolean
key_press_func(GtkWidget* widget, GdkEventKey* key,
               gpointer data)
{
#define KEY_ENTER 0xff0d
#define KEY_ESC   0xff1b
	GtkWidget *button = (GtkWidget*)data;
	DBG("Key Press val = 0x%x\n", key->keyval);
    if (KEY_ENTER == key->keyval) {
		connect_handler(GTK_BUTTON(button), NULL); 
        return TRUE;
    } else if (KEY_ESC == key->keyval) {
		conn_stutas = FALSE; 
        gtk_main_quit();
    }
	return FALSE;
#undef  KEY_ENTER
#undef  KEY_ESC
} 

static gboolean
buttonarea_setup(GtkWidget* window, GtkWidget* box)
{
	GtkWidget *bbox;
	GtkWidget *button;
	
	bbox = gtk_hbutton_box_new();
    gtk_box_pack_start_defaults(GTK_BOX(box), bbox);
	
	gtk_box_set_spacing(GTK_BOX(bbox), 5);
	gtk_button_box_set_layout(GTK_BUTTON_BOX(bbox), 
	                          GTK_BUTTONBOX_END);	
	
	//Connect Button
	button = gtk_button_new_with_label("Connect");  
    gtk_box_pack_start_defaults(GTK_BOX(bbox), button);
	
    gtk_signal_connect(GTK_OBJECT(button), "clicked",
                       GTK_SIGNAL_FUNC(connect_handler),
                       window);		
	
    gtk_signal_connect(GTK_OBJECT(button), "enter",
                       GTK_SIGNAL_FUNC(button_enter),
                       (gpointer)MID_CONN_PROMPT);	
	
    conn_btn_leave_id = 
		gtk_signal_connect(GTK_OBJECT(button), "leave",
                           GTK_SIGNAL_FUNC(button_leave),
                           (gpointer)MID_CONN_PROMPT);	

    g_signal_connect(G_OBJECT(window), "key_press_event",
                     G_CALLBACK(key_press_func), button);						   
	
	//Quit Button
	button = gtk_button_new_with_label("Quit");  
    gtk_box_pack_start_defaults(GTK_BOX(bbox), button);
	
    gtk_signal_connect(GTK_OBJECT(button), "clicked",
                       GTK_SIGNAL_FUNC(gtk_main_quit),
                       window);	
		
    gtk_signal_connect(GTK_OBJECT(button), "enter",
                       GTK_SIGNAL_FUNC(button_enter),
                       (gpointer)MID_QUIT_PROMPT);	
	
    gtk_signal_connect(GTK_OBJECT(button), "leave",
                       GTK_SIGNAL_FUNC(button_leave),
                       (gpointer)MID_QUIT_PROMPT);		
	
	return TRUE;
}

////////////////////////////////
//  STATUSBAR
//
static gboolean
statusbar_setup(GtkWidget* window, GtkWidget* box)
{
	gint i;
	
	statusbar = gtk_statusbar_new();
	gtk_box_pack_start_defaults(GTK_BOX(box), statusbar);
	
	for (i = 0; i < sizeof(g_status_msg)/sizeof(struct status_msg ); i++) {
		g_status_msg[i].cid =
			gtk_statusbar_get_context_id(GTK_STATUSBAR(statusbar),
	                                     g_status_msg[i].text);
	}
									 
	gtk_statusbar_push(GTK_STATUSBAR(statusbar), 
	                   g_status_msg[MID_FIRST_PROMPT].cid, 
	                   g_status_msg[MID_FIRST_PROMPT].text);	
					   
	return TRUE;
}

static gboolean
init_conn_if(GtkWidget* window)
{
    GtkWidget *vbox;
    GtkWidget *hbox;	

    vbox=gtk_vbox_new(FALSE, 5);
    gtk_container_add(GTK_CONTAINER(window), vbox);          
 	//----------------------------------------------------------   
 	//logo
    hbox=gtk_hbox_new(FALSE, 5);
    gtk_box_pack_start_defaults(GTK_BOX(vbox), hbox);
	
	imagearea_setup(window, hbox);
	//----------------------------------------------------------
	//entry
	hbox=gtk_hbox_new(FALSE, 5);
    gtk_box_pack_start_defaults(GTK_BOX(vbox), hbox);
	
	entryarea_setup(window, hbox);
	//----------------------------------------------------------
	//button
	buttonarea_setup(window, vbox);
	//----------------------------------------------------------
	//statusbar
	statusbar_setup(window, vbox);	
	//----------------------------------------------------------    
    return TRUE;
}

/*
 * ��������Ӧ�ó���
 * */
gboolean connect_app(void)
{
    GtkWidget* window;
    	
    window = gtk_window_new(GTK_WINDOW_TOPLEVEL);     //�½�һ�����㴰��
 
    gtk_window_set_title(GTK_WINDOW(window), WIN_TITLE);  //���ô��ڱ���
    gtk_window_set_position(GTK_WINDOW(window), GTK_WIN_POS_CENTER);  //���ڳ�����������
    gtk_window_set_icon(GTK_WINDOW(window), 
                        gdk_pixbuf_new_from_file(WIN_ICON, NULL));
    gtk_window_set_resizable(GTK_WINDOW(window), FALSE);       //���ɸı䴰�ڴ�С
    gtk_container_set_border_width(GTK_CONTAINER(window), 0);  //���ڱ߿��С����Ϊ0 
    gtk_signal_connect(GTK_OBJECT(window), "destroy",
                       GTK_SIGNAL_FUNC(gtk_main_quit),NULL);
    
    gtk_widget_set_app_paintable(window, TRUE);
    gtk_widget_realize(window);

	init_conn_if(window);
	
    gtk_widget_show_all(window);
	
	gdk_threads_enter();
	gtk_main();
	gdk_threads_leave();	
	
	if (TRUE == GTK_IS_WIDGET(window))
		gtk_widget_hide_all(window);
    //gtk_widget_destroy(window);
    //g_object_unref(G_OBJECT(window));
	
    return conn_stutas;
}
