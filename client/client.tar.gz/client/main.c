#include "stdinc.h"
#include "gcamwin.h"
#include "webcam.h"

GThread *g_cam_thread = NULL;
GMutex  *g_cam_mutex  = NULL;
GCond   *g_cam_cond   = NULL;

/*
 * 主函数入口
 * */
gint main(gint argc,gchar* argv[])
{			
	if(!g_thread_supported()) 
		g_thread_init(NULL);
	gdk_threads_init();
    
    gtk_init(&argc, &argv);
	
	g_cam_mutex = g_mutex_new();
	g_cam_cond  = g_cond_new();	
    
	g_thread_create(cam_thread, NULL, FALSE, NULL);	
	
    if(FALSE == connect_app()) 
		_exit(EXIT_SUCCESS);

	DBG("Connection successful!\n");
	
	if(create_main_app()) {	
		gdk_threads_enter();
        gtk_main();
        gdk_threads_leave();		
	}	
	g_mutex_lock(g_cam_mutex);
	g_mutex_unlock(g_cam_mutex);
	//Calling g_mutex_free() on a locked mutex may result in undefined behaviour.
	//so call g_mutex_unlock() first!
	g_mutex_free(g_cam_mutex); 
	g_cond_free(g_cam_cond);
	
    _exit(EXIT_SUCCESS);
}




